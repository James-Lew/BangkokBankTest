package com.example.BangkokBankTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BangkokBankTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
