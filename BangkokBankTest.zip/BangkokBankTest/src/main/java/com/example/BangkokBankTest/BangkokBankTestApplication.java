package com.example.BangkokBankTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BangkokBankTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BangkokBankTestApplication.class, args);
	}

}
